<script>
import axios from 'axios';

export default {
    data() {
        return {
            repositories: [],
            isSearchReposByName: '',
            isSearchReposByID: '',
            isActiveAllRepos: false
        }
    },
    methods: {

        async LoadRepositories() {
            const response = await axios('/repos');
            this.repositories = response.data;
        },

        async syncInterval() {
            await axios.post('/sync');
        },

        active() {
            this.isActiveAllRepos = !this.isActiveAllRepos;
        }
    },
    mounted() {
        this.LoadRepositories();
        this.syncInterval();
    },
    computed: {
        sortedReposByName() {
            return this.repositories.filter(repos => {
                if (this.isSearchReposByName === '') {
                    return true;
                } else {
                    return repos.name.indexOf(this.isSearchReposByName) > -1;
                }
            });
        },

        sortedReposByID() {
            return this.repositories.filter(repos => this.isSearchReposByID == repos.id)
        }
    }
}
</script>

<template>

    <div class="container">
        <div class="mb-3">
            <label for="formGroupExampleInput" class="form-label">Поиск репозитория по имени</label>
            <input v-model="isSearchReposByName" type="text" class="form-control" id="formGroupExampleInput"
                placeholder="Введите имя">
        </div>
        <div class="mb-3">
            <label for="formGroupExampleInput2" class="form-label">Поиск репозитория по индетификатору</label>
            <input v-model="isSearchReposByID" type="number" class="form-control" id="formGroupExampleInput2" placeholder="Введите ID">
        </div>
    </div>
    
    
    <div class="container list_repositories">
        <app-button @click="active">Получить все репозитории</app-button>

        <transition-group name="repos-list">
            <div v-if="isSearchReposByName != '' " v-for="repos of sortedReposByName" class="card" style="margin: 4vh 0;">
                <h5 class="card-header">{{repos.id}}.{{ repos.name }}</h5>
                <div class="card-body">
                    <h5 style="color: #790b9bd2;" class="card-title">{{ repos.full_name }}</h5>
                    <p class="card-text">{{ repos.description }}</p>
                    <form :action="repos.html_url" target="_blank">
                        <app-button>Let's go...</app-button>
                    </form>
                </div>
            </div>
        </transition-group>

        <transition-group name="repos-list">
            <div v-if="isSearchReposByID != '' " v-for="repos of sortedReposByID" class="card" style="margin: 4vh 0;">
                <h5 class="card-header">{{repos.id}}.{{ repos.name }}</h5>
                <div class="card-body">
                    <h5 style="color: #790b9bd2;" class="card-title">{{ repos.full_name }}</h5>
                    <p class="card-text">{{ repos.description }}</p>
                    <form :action="repos.html_url" target="_blank">
                        <app-button>Let's go...</app-button>
                    </form>
                </div>
            </div>
        </transition-group>

        <transition-group name="repos-list">
            <div v-if="isActiveAllRepos" v-for="repos of repositories" class="card" style="margin: 4vh 0;">
                <h5 class="card-header">{{repos.id}}.{{ repos.name }}</h5>
                <div class="card-body">
                    <h5 style="color: #790b9bd2;" class="card-title">{{ repos.full_name }}</h5>
                    <p class="card-text">{{ repos.description }}</p>
                    <form :action="repos.html_url" target="_blank">
                        <app-button>Let's go...</app-button>
                    </form>
                </div>
            </div>
        </transition-group>

    </div>

</template>

<style scoped>
.list_repositories {
    padding: 10vh;
}

.repos-list-item {
  display: inline-block;
  margin-right: 10px;
}
.repos-list-enter-active,
.repos-list-leave-active {
  transition: all 500ms ease;
}
.repos-list-enter-from,
.repos-list-leave-to {
  opacity: 0;
  transform: translateX(30px);
}
.repos-list-move {
  transition: transform 0.4s ease}
</style>