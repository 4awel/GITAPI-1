<script>
import axios from 'axios';
import { RouterView } from 'vue-router';
import AppHeader from './components/AppHeader.vue';

export default {

  components: {
    AppHeader,
    RouterView
  },

  data() {
    return {
      repositories: [],
    }
  },
  methods: {

  },
  mounted() {
  }
}

</script>

<template>
  <div id="app">

    <header>
      <app-header></app-header>
    </header>
    <main>
      <router-view></router-view>
    </main>
    <footer>
    </footer>

  </div>

</template>

<style scoped>
h1 {
  margin: 20px;
}

header {
padding: 10vh;
}

</style>
