<script>

</script>

<template>

    <div class="container">
        <div>
            <b>Hellow, <...GITAPI/>! </b>
        </div>
        <div>
            <app-button>< NodeJS... /></app-button>
        </div>
    </div>
  
</template>

<style scoped>
b {
    font-size: 8vh;
}
</style>