<script>
export default {
  name: 'app-button'
}
</script>

<template>
  <button type="submit" class="app-button">
      <slot></slot>
  </button>
</template>

<style scoped>
.app-button {
  color: #fff;
  padding: 10px;
  padding: 10px 24px;
  background-color: #790b9bd2;
  border: none;
}

.app-button:hover {
  transition: all 500ms;
  background-color: #460b6dd2;
}
</style>