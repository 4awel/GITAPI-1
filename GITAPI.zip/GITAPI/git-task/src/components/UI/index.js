import AppButton from '@/components/UI/AppButton.vue';
import AppInput from '@/components/UI/AppInput.vue';

export default [
    AppButton,
    AppInput,
]