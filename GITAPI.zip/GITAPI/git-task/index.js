// Settng express
import express, { json } from "express";
const app = express();
const PORT = process.env.PORT || 3005;
import { createRequire } from "module";
const require = createRequire(import.meta.url);
require("dotenv").config();
const { command, program } = require("commander");

// Settng server
app.listen(PORT, function () {
  console.log(`http:127.0.0.1:27017:${PORT}`);
});

// Settng db
import { connect, mongoose } from "mongoose";
connect("mongodb://127.0.0.1:27017/Git-API")
  .then(() => console.log("MDB подключена"))
  .catch((err) => console.log(err));

// Settng CORS
import cors from "cors";
import axios from "axios";
import { log } from "console";

app.use(
  cors({
    origin: "http://localhost:5173",
  })
);

// Settng POST-request -> JSON
app.use(json());

const repoSchema = new mongoose.Schema({
  id: { type: Number, unique: true },
  name: String,
  full_name: String,
  html_url: String,
  description: String,
  stargazers_count: Number,
  updated_at: Date,
});

const Repo = mongoose.model("repo", repoSchema);

let syncInterval;

async function fetchTrendingRepositories() {
  try {
    const response = await axios(
      "https://api.github.com/repositories?sort=stars&order=desc",
      {
        headers: {
          Authorization: `token ${process.env.GITHUB_TOKEN}`,
        },
      }
    );

    const repos = response.data;
    // console.log(repos);

    for (const repo of repos) {
      // Обновляем или добавляем в БД
      if (repo.id != null) {
        await Repo.updateOne(
          { id: repo.id },
          {
            name: repo.name,
            full_name: repo.full_name,
            html_url: repo.html_url,
            description: repo.description,
            stargazers_count: repo.stargazers_count,
            updated_at: repo.updated_at,
          },
          { upsert: true }
        );
      }
    }
    console.log("Репозитории успешно обновлены");
  } catch (error) {
    console.error("Ошибка при выборке репозиториев:", error);
  }
}

app.get("/repos", async (req, res) => {
  try {
    const repos = await Repo.find({});

    res.send(repos);
  } catch (err) {
    res.status(500).send(err);
  }
});

app.post("/sync", async (req, res) => {
  if (syncInterval) {
    clearInterval(syncInterval); // Сбрасываем предыдущий таймер
    console.log("Предыдущий интервал синхронизации очищен");
  }

  await fetchTrendingRepositories(); // Принудительная синхронизация

  // Запускаем автоматическую синхронизацию
  syncInterval = setInterval(fetchTrendingRepositories, 360000);

  res.send("Синхронизация начата");
});

// Устанавливаем интервал для повторной выборки
const intervalMinutes = 10;
setInterval(fetchTrendingRepositories, intervalMinutes * 60 * 1000);

// Начальная выборка при запуске
fetchTrendingRepositories();

// CLI команды
// List
program
  .command("repos")
  .description("Получить список всех репозиторий")
  .action(async () => {
    const repos = await Repo.find({});
    console.log("Repositories list:", repos);
  });

// Search
program
  .command("id <id>")
  .description("Поиск репозиторий по индетифекатору")
  .action(async (identifier) => {
    const serachRepo = await Repo.findOne({ id: identifier });
    if (serachRepo) {
      console.log("Репозиторий успешно найден ->", serachRepo);
    } else {
      console.log("404: Репозиторий не найден!");
    }
  });

program
  .command("name <name>")
  .description("Поиск репозиторий по имени")
  .action(async (name) => {
    const serachRepo = await Repo.findOne({ name: name });
    if (serachRepo) {
      console.log("Репозиторий успешно найден ->", serachRepo);
    } else {
      console.log("404: Репозиторий не найден!");
    }
  });

program
  .command("run")
  .description("Запустить сервер")
  .action(async () => {
    console.log("Сервер запущен");
  });

program
  .command("info")
  .description("Важная информация для запуска сервера и его пользованием")
  .action(async () => {
    console.log("Приветствую, дорогой пользователь, это GITAPI! Тут информация о том как пользоваться, данным CLI.");
    console.log('Чтобы запустить сервер с CLI-клиентом, необходимо использовать команду "npm start run", чтобы вписать следующую команду необходимо выключить сервер CTRL + C ');
    console.log('В данной программе все выполняеться через npm start <команада> или yarn start <команада>');
    console.log('Также тут есть поиск: npm start <id || name> <argument>');
    console.log('Приятного пользования, с уважением GITAPI');
  });

program.parse(process.argv);
